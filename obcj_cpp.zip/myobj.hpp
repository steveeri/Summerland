
class MyObj {

public:
    int val;
    const char* name; 
    MyObj();
    MyObj(int v);
};
