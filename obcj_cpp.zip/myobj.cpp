
#include "myobj.hpp"

MyObj::MyObj() {
    val = 5;
    name = "Steve";
}

MyObj::MyObj(int v) {
    val = v;
    name = "Steve";
}
